# Perform testing of hypothesis using Wilcoxon Rank Sum Test (Mann-Whitney U Test).

from scipy.stats import mannwhitneyu
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def mann_whitney_test(data1,data2,alternative='two-sided'):
    result=mannwhitneyu(data1,data2,alternative=alternative)
    return result.statistic,result.pvalue
print("Sample 1:")
data1=input_data()
print("Sample 2:")
data2=input_data()
alt=alt if (alt:=input("Enter the type of test: ")) else 'two-sided'
alpha=float(input("Enter the value of alpha: "))
results=mann_whitney_test(data1,data2,alternative=alt)
print("U = test statistic:",results[0])
print("p-value:",results[1])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
