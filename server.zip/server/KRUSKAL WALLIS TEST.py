# Perform testing of hypothesis using Kruskal-Wallis Test

from scipy import stats
from scipy.stats import kruskal
data_group1=[23,41,54,66,78]
data_group2=[45,55,60,70,72]
data_group3=[20,30,34,40,44]
result=kruskal(data_group1,data_group2,data_group3)
print(result)
print("Test Statistic:",result[0])
print("p-value:",result[1])
p_value=result[1]
if p_value<0.05:
    print("H0 is rejected")
else:
    print("H0 is accepted")

#WITH USER INPUT

# Perform testing of hypothesis using Kruskal-Wallis Test
from scipy.stats import kruskal
def input_data(n):
    data=[]
    for i in range(n):
        value=float(input(f"Enter element {i+1}: "))
        data.append(value)
    return data
n1=int(input("Enter number of elements in group 1: "))
data_group1=input_data(n1)
n2=int(input("Enter number of elements in group 2: "))
data_group2=input_data(n2)
n3=int(input("Enter number of elements in group 3: "))
data_group3=input_data(n3)
result=kruskal(data_group1,data_group2,data_group3)
print(result)
print("Test Statistic:",result[0])
print("p-value:",result[1])
p_value=result[1]
if p_value<0.05:
    print("H0 is rejected")
else:
    print("H0 is accepted")
