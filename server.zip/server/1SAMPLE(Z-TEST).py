# Perform testing of hypothesis for mean of one sample using z-test.

from scipy.stats import norm
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def z_test(data,pop_mean,pop_sd,alternative='two-sided'):
    n=len(data)
    xbar=np.mean(data)
    Z=(xbar-pop_mean)/(pop_sd/(n**0.5))
    if alternative=='two-sided':
        return Z,2*min(norm.cdf(Z),norm.sf(Z))
    elif alternative=='right':
        return Z,norm.sf(Z)
    elif alternative=='left':
        return Z,norm.cdf(Z)
    else:
        raise ValueError("alternative must be 'two-sided', 'right', or 'left'")
data=input_data()
mu=float(input("Enter population mean: "))
sigma=float(input("Enter population standard deviation: "))
alt=alt if (alt:=input("Enter type of test: ")) else 'two-sided'
alpha=float(input("Enter alpha value (decimals): "))
results=z_test(data,mu,sigma,alternative=alt)
print("Z0 = test statistic:",results[0])
print("p-value:",results[1])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
