# Perform testing of hypothesis for equality of mean of two samples using t-test (independent).

from scipy.stats import t
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def ttest_ind(data1,data2,alternative='two-sided'):
    n1=len(data1)
    n2=len(data2)
    x1bar=np.mean(data1)
    x2bar=np.mean(data2)
    var1=np.var(data1,ddof=1)
    var2=np.var(data2,ddof=1)
    dof=n1+n2-2
    var=((n1-1)*var1+(n2-1)*var2)/dof
    T=(x1bar-x2bar)/((var/n1)+(var/n2))**0.5
    if alternative=='two-sided':
        return T,2*min(t.cdf(T,dof),t.sf(T,dof)),dof
    elif alternative=='right':
        return T,t.sf(T,dof),dof
    elif alternative=='left':
        return T,t.cdf(T,dof),dof
    else:
        raise ValueError("alternative must be 'left', 'right' or 'two-sided'")
print("Sample 1:")
data1=input_data()
print("Sample 2:")
data2=input_data()
alt=alt if (alt:=input("Enter the type of test: ")) else 'two-sided'
alpha=float(input("Enter the value of alpha: "))
results=ttest_ind(data1,data2,alternative=alt)
print("t0 = test statistic:",results[0])
print("p-value:",results[1])
print("Degrees of freedom:",results[2])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
