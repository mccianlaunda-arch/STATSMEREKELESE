# Perform testing of hypothesis for fitting/independence using Chi-Square test.

from scipy.stats import chi2
import numpy as np
def input_data(rows,cols):
    data=[]
    for i in range(rows):
        row=[]
        for j in range(cols):
            value=float(input(f"Enter element [{i+1},{j+1}]: "))
            row.append(value)
        data.append(row)
    return np.array(data)
def chi_square_test(data):
    row_total=np.sum(data,axis=1)
    col_total=np.sum(data,axis=0)
    total=np.sum(data)
    expected=np.outer(row_total,col_total)/total
    chi=np.sum((data-expected)**2/expected)
    dof=(data.shape[0]-1)*(data.shape[1]-1)
    p_value=chi2.sf(chi,dof)
    return chi,p_value,dof
rows=int(input("Enter number of rows: "))
cols=int(input("Enter number of columns: "))
data=input_data(rows,cols)
alpha=float(input("Enter the value of alpha: "))
results=chi_square_test(data)
print("Chi-square = test statistic:",results[0])
print("p-value:",results[1])
print("Degrees of freedom:",results[2])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
