# Perform testing of hypothesis for mean of one sample using t-test.

from scipy.stats import t
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def t_test(data,pop_mean,alternative='two-sided'):
    n=len(data)
    xbar=np.mean(data)
    s=np.std(data,ddof=1)
    T=(xbar-pop_mean)/(s/(n**0.5))
    dof=n-1
    if alternative=='two-sided':
        return T,2*min(t.cdf(T,dof),t.sf(T,dof))
    elif alternative=='right':
        return T,t.sf(T,dof)
    elif alternative=='left':
        return T,t.cdf(T,dof)
    else:
        raise ValueError("alternative must be 'two-sided', 'right', or 'left'")
data=input_data()
mu=float(input("Enter population mean: "))
alt=alt if (alt:=input("Enter type of test: ")) else 'two-sided'
alpha=float(input("Enter alpha value (decimals): "))
results=t_test(data,mu,alternative=alt)
print("t0 = test statistic:",results[0])
print("p-value:",results[1])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
