# Perform testing of hypothesis for equality of mean of two samples using z-test.

from scipy.stats import norm
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def ztest_ind(data1,data2,pop_sd1,pop_sd2,alternative='two-sided'):
    n1=len(data1)
    n2=len(data2)
    x1bar=np.mean(data1)
    x2bar=np.mean(data2)
    Z=(x1bar-x2bar)/((pop_sd1**2/n1)+(pop_sd2**2/n2))**0.5
    if alternative=='two-sided':
        return Z,2*min(norm.cdf(Z),norm.sf(Z))
    elif alternative=='right':
        return Z,norm.sf(Z)
    elif alternative=='left':
        return Z,norm.cdf(Z)
    else:
        raise ValueError("alternative must be 'left', 'right' or 'two-sided'")
print("Sample 1:")
data1=input_data()
print("Sample 2:")
data2=input_data()
sigma1=float(input("Enter population standard deviation of sample 1: "))
sigma2=float(input("Enter population standard deviation of sample 2: "))
alt=alt if (alt:=input("Enter the type of test: ")) else 'two-sided'
alpha=float(input("Enter the value of alpha: "))
results=ztest_ind(data1,data2,sigma1,sigma2,alternative=alt)
print("Z0 = test statistic:",results[0])
print("p-value:",results[1])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
