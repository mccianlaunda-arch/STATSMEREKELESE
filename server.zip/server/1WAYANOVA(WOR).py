# Perform testing of hypothesis using two-way ANOVA (Without Replication).

import numpy as np
from scipy.stats import f
def input_data(rows,cols):
    data=[]
    for i in range(rows):
        row=[]
        for j in range(cols):
            value=float(input(f"Enter element [{i+1},{j+1}]: "))
            row.append(value)
        data.append(row)
    return np.array(data)
rows=int(input("Enter number of rows: "))
cols=int(input("Enter number of columns: "))
data=input_data(rows,cols)
alpha=float(input("Enter the value of alpha: "))
grand_mean=np.mean(data)
row_means=np.mean(data,axis=1)
col_means=np.mean(data,axis=0)
ss_rows=cols*np.sum((row_means-grand_mean)**2)
ss_cols=rows*np.sum((col_means-grand_mean)**2)
ss_total=np.sum((data-grand_mean)**2)
ss_error=ss_total-ss_rows-ss_cols
df_rows=rows-1
df_cols=cols-1
df_error=(rows-1)*(cols-1)
ms_rows=ss_rows/df_rows
ms_cols=ss_cols/df_cols
ms_error=ss_error/df_error
F_rows=ms_rows/ms_error
F_cols=ms_cols/ms_error
p_rows=f.sf(F_rows,df_rows,df_error)
p_cols=f.sf(F_cols,df_cols,df_error)
print("F value for rows:",F_rows)
print("p-value for rows:",p_rows)
print("F value for columns:",F_cols)
print("p-value for columns:",p_cols)
if p_rows<alpha:
    print("Reject the null hypothesis for rows")
else:
    print("Fail to reject the null hypothesis for rows")
if p_cols<alpha:
    print("Reject the null hypothesis for columns")
else:
    print("Fail to reject the null hypothesis for columns")
