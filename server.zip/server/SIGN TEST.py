# Perform testing of hypothesis using Sign Test.

from scipy.stats import binomtest
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def sign_test(data,median,alternative='two-sided'):
    differences=np.array(data)-median
    differences=differences[differences!=0]
    positive=np.sum(differences>0)
    negative=np.sum(differences<0)
    n=positive+negative
    result=binomtest(positive,n,0.5,alternative=alternative)
    return positive,negative,result.pvalue
data=input_data()
median=float(input("Enter hypothesized median: "))
alt=alt if (alt:=input("Enter the type of test: ")) else 'two-sided'
alpha=float(input("Enter the value of alpha: "))
results=sign_test(data,median,alternative=alt)
print("Positive signs:",results[0])
print("Negative signs:",results[1])
print("p-value:",results[2])
p_value=results[2]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
