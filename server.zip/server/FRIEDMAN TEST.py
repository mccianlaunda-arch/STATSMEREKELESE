# Perform testing of hypothesis using Friedman Test

from scipy.stats import friedmanchisquare
data_group1=[39,29,36,29,31,34]
data_group2=[38,25,37,29,27,33]
data_group3=[34,20,29,18,24,30]
data_group4=[33,20,24,19,22,31]
result=friedmanchisquare(data_group1,data_group2,data_group3,data_group4)
print(result)
print("Test Statistic:",result[0])
print("p-value:",result[1])
p_value=result[1]
if p_value<0.05:
    print("H0 is rejected")
else:
    print("H0 is accepted")

# WITH USER INPUT

# Perform testing of hypothesis using Friedman Test
from scipy.stats import friedmanchisquare
def input_data(n):
    data=[]
    for i in range(n):
        value=float(input(f"Enter element {i+1}: "))
        data.append(value)
    return data
n=int(input("Enter number of elements in each group: "))
print("Group 1:")
data_group1=input_data(n)
print("Group 2:")
data_group2=input_data(n)
print("Group 3:")
data_group3=input_data(n)
print("Group 4:")
data_group4=input_data(n)
result=friedmanchisquare(data_group1,data_group2,data_group3,data_group4)
print(result)
print("Test Statistic:",result[0])
print("p-value:",result[1])
p_value=result[1]
if p_value<0.05:
    print("H0 is rejected")
else:
    print("H0 is accepted")
