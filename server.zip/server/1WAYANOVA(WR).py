# Perform testing of hypothesis using two-way ANOVA (With Replication).

import numpy as np
from scipy.stats import f
def input_data(rows,cols,replications):
    data=np.zeros((rows,cols,replications))
    for i in range(rows):
        for j in range(cols):
            for k in range(replications):
                data[i,j,k]=float(input(f"Enter element [{i+1},{j+1},{k+1}]: "))
    return data
rows=int(input("Enter number of rows: "))
cols=int(input("Enter number of columns: "))
replications=int(input("Enter number of replications: "))
data=input_data(rows,cols,replications)
alpha=float(input("Enter the value of alpha: "))
grand_mean=np.mean(data)
row_means=np.mean(data,axis=(1,2))
col_means=np.mean(data,axis=(0,2))
cell_means=np.mean(data,axis=2)
ss_rows=cols*replications*np.sum((row_means-grand_mean)**2)
ss_cols=rows*replications*np.sum((col_means-grand_mean)**2)
ss_interaction=replications*np.sum((cell_means-row_means[:,np.newaxis]-col_means[np.newaxis,:]+grand_mean)**2)
ss_total=np.sum((data-grand_mean)**2)
ss_error=ss_total-ss_rows-ss_cols-ss_interaction
df_rows=rows-1
df_cols=cols-1
df_interaction=(rows-1)*(cols-1)
df_error=rows*cols*(replications-1)
ms_rows=ss_rows/df_rows
ms_cols=ss_cols/df_cols
ms_interaction=ss_interaction/df_interaction
ms_error=ss_error/df_error
F_rows=ms_rows/ms_error
F_cols=ms_cols/ms_error
F_interaction=ms_interaction/ms_error
p_rows=f.sf(F_rows,df_rows,df_error)
p_cols=f.sf(F_cols,df_cols,df_error)
p_interaction=f.sf(F_interaction,df_interaction,df_error)
print("F value for rows:",F_rows)
print("p-value for rows:",p_rows)
print("F value for columns:",F_cols)
print("p-value for columns:",p_cols)
print("F value for interaction:",F_interaction)
print("p-value for interaction:",p_interaction)
if p_rows<alpha:
    print("Reject the null hypothesis for rows")
else:
    print("Fail to reject the null hypothesis for rows")
if p_cols<alpha:
    print("Reject the null hypothesis for columns")
else:
    print("Fail to reject the null hypothesis for columns")
if p_interaction<alpha:
    print("Reject the null hypothesis for interaction")
else:
    print("Fail to reject the null hypothesis for interaction")
