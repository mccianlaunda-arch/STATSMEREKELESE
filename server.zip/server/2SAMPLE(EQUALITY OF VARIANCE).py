# Perform testing of hypothesis for equality of variances of two samples.

from scipy.stats import f
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def variance_test_two(data1,data2,alternative='two-sided'):
    n1=len(data1)
    n2=len(data2)
    var1=np.var(data1,ddof=1)
    var2=np.var(data2,ddof=1)
    dof1=n1-1
    dof2=n2-1
    F=var1/var2
    if alternative=='two-sided':
        p_value=2*min(f.cdf(F,dof1,dof2),f.sf(F,dof1,dof2))
        return F,p_value,dof1,dof2
    elif alternative=='right':
        return F,f.sf(F,dof1,dof2),dof1,dof2
    elif alternative=='left':
        return F,f.cdf(F,dof1,dof2),dof1,dof2
    else:
        raise ValueError("alternative must be 'left', 'right' or 'two-sided'")
print("Sample 1:")
data1=input_data()
print("Sample 2:")
data2=input_data()
alt=alt if (alt:=input("Enter the type of test: ")) else 'two-sided'
alpha=float(input("Enter the value of alpha: "))
results=variance_test_two(data1,data2,alternative=alt)
print("F = test statistic:",results[0])
print("p-value:",results[1])
print("Degrees of freedom:",results[2],results[3])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
