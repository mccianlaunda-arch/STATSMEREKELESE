# Perform testing of hypothesis for equality of mean of two samples using t-test (dependent).

from scipy.stats import t
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def ttest_dep(data1,data2,alternative='two-sided'):
    d=[elem1-elem2 for elem1,elem2 in zip(data1,data2,strict=True)]
    n=len(d)
    dbar=np.mean(d)
    s=np.std(d,ddof=1)
    T=dbar/(s/(n**0.5))
    dof=n-1
    if alternative=='two-sided':
        return T,2*min(t.cdf(T,dof),t.sf(T,dof)),dof
    elif alternative=='right':
        return T,t.sf(T,dof),dof
    elif alternative=='left':
        return T,t.cdf(T,dof),dof
    else:
        raise ValueError("alternative must be 'left', 'right' or 'two-sided'")
print("Sample 1:")
data1=input_data()
print("Sample 2:")
data2=input_data()
alt=alt if (alt:=input("Enter the type of test: ")) else 'two-sided'
alpha=float(input("Enter the value of alpha: "))
results=ttest_dep(data1,data2,alternative=alt)
print("t0 = test statistic:",results[0])
print("p-value:",results[1])
print("Degrees of freedom:",results[2])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
