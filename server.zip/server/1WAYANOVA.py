# Perform testing of hypothesis using one-way ANOVA.

from scipy.stats import f
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def one_way_anova(*groups):
    k=len(groups)
    n=sum(len(group) for group in groups)
    grand_mean=np.mean([x for group in groups for x in group])
    ss_between=sum(len(group)*(np.mean(group)-grand_mean)**2 for group in groups)
    ss_within=sum(sum((x-np.mean(group))**2 for x in group) for group in groups)
    df_between=k-1
    df_within=n-k
    ms_between=ss_between/df_between
    ms_within=ss_within/df_within
    F=ms_between/ms_within
    p_value=f.sf(F,df_between,df_within)
    return F,p_value,df_between,df_within
print("Group 1:")
data1=input_data()
print("Group 2:")
data2=input_data()
print("Group 3:")
data3=input_data()
alpha=float(input("Enter the value of alpha: "))
results=one_way_anova(data1,data2,data3)
print("F = test statistic:",results[0])
print("p-value:",results[1])
print("Degrees of freedom:",results[2],results[3])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
