# Perform testing of hypothesis using Mood's Median Test

from scipy.stats import median_test
data_group1=[1,14,19,12,11,15,20,9,21,19,19,20,3,6]
data_group2=[16,17,19,10,31,22,26,24,27,32,14,8,12,1]
result=median_test(data_group1,data_group2)
print(result)
print("Test Statistic:",result[0])
print("p-value:",result[1])
p_value=result[1]
if p_value<0.05:
    print("H0 is rejected")
else:
    print("H0 is accepted")

#WITH USER INPUT

# Perform testing of hypothesis using Mood's Median Test
from scipy.stats import median_test
def input_data(n):
    data=[]
    for i in range(n):
        value=float(input(f"Enter element {i+1}: "))
        data.append(value)
    return data
n1=int(input("Enter number of elements in group 1: "))
print("Group 1:")
data_group1=input_data(n1)
n2=int(input("Enter number of elements in group 2: "))
print("Group 2:")
data_group2=input_data(n2)
result=median_test(data_group1,data_group2)
print(result)
print("Test Statistic:",result[0])
print("p-value:",result[1])
p_value=result[1]
if p_value<0.05:
    print("H0 is rejected")
else:
    print("H0 is accepted")
