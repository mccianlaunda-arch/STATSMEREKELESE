# Perform testing of hypothesis for variance of one sample.

from scipy.stats import chi2
import numpy as np
def input_data(n=None,dtype=float):
    data=[]
    i=0
    while True:
        if i==n:
            return data
        inp=input(f"Enter element {i+1}: ")
        if not inp and n is None:
            return data
        data.append(dtype(inp))
        i+=1
def variance_test(data,pop_var,alternative='two-sided'):
    n=len(data)
    sample_var=np.var(data,ddof=1)
    dof=n-1
    chi=((n-1)*sample_var)/pop_var
    if alternative=='two-sided':
        p_value=2*min(chi2.cdf(chi,dof),chi2.sf(chi,dof))
        return chi,p_value,dof
    elif alternative=='right':
        return chi,chi2.sf(chi,dof),dof
    elif alternative=='left':
        return chi,chi2.cdf(chi,dof),dof
    else:
        raise ValueError("alternative must be 'left', 'right' or 'two-sided'")
data=input_data()
pop_var=float(input("Enter population variance: "))
alt=alt if (alt:=input("Enter the type of test: ")) else 'two-sided'
alpha=float(input("Enter the value of alpha: "))
results=variance_test(data,pop_var,alternative=alt)
print("Chi-square = test statistic:",results[0])
print("p-value:",results[1])
print("Degrees of freedom:",results[2])
p_value=results[1]
if p_value<alpha:
    print("Reject the null hypothesis")
else:
    print("Fail to reject the null hypothesis")
